<?php
require_once('CRUD.php');

class Motorcycle {
    // Properties
    public $id;
    public $brand;
    public $model;
    public $year;
    public $price;
    public $available;

    private $crud;

    // Constructor
    public function __construct() {
        $this->crud = new CRUD();
    }

    // Create a new motorcycle
    public function create() {
        $data = [
            'brand' => $this->brand,
            'model' => $this->model,
            'year' => $this->year,
            'price' => $this->price,
            'available' => $this->available,
        ];
        return $this->crud->create('motorcycles', $data);
    }

    // Read motorcycles
    public function read($id = null) {
        return $this->crud->read('motorcycles', $id);
    }

    // Update a motorcycle
    public function update() {
        $data = [
            'brand' => $this->brand,
            'model' => $this->model,
            'year' => $this->year,
            'price' => $this->price,
            'available' => $this->available,
        ];
        return $this->crud->update('motorcycles', $this->id, $data);
    }

    // Delete a motorcycle
    public function delete() {
        return $this->crud->delete('motorcycles', $this->id);
    }

    // Method to display motorcycle details
    public function display() {
        echo "<p>Motorcycle ID: {$this->id}</p>";
        echo "<p>Brand: {$this->brand}</p>";
        echo "<p>Model: {$this->model}</p>";
        echo "<p>Year: {$this->year}</p>";
        echo "<p>Price: {$this->price} USD</p>";
        echo "<p>Available: " . ($this->available ? 'Yes' : 'No') . "</p>";
    }
}
?>
