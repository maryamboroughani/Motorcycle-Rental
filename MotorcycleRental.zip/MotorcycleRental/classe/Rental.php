<?php
require_once('CRUD.php');

class Rental {
    // Properties
    public $id;
    public $motorcycle_id;
    public $user_id;
    public $start_date;
    public $end_date;

    private $crud;

    // Constructor
    public function __construct() {
        $this->crud = new CRUD();
    }

    // Create a new rental
    public function create() {
        $data = [
            'motorcycle_id' => $this->motorcycle_id,
            'user_id' => $this->user_id,
            'start_date' => $this->start_date,
            'end_date' => $this->end_date,
        ];
        return $this->crud->create('rentals', $data);
    }

    // Read rentals
    public function read($id = null) {
        return $this->crud->read('rentals', $id);
    }

    // Update a rental
    public function update() {
        $data = [
            'motorcycle_id' => $this->motorcycle_id,
            'user_id' => $this->user_id,
            'start_date' => $this->start_date,
            'end_date' => $this->end_date,
        ];
        return $this->crud->update('rentals', $this->id, $data);
    }

    // Delete a rental
    public function delete() {
        return $this->crud->delete('rentals', $this->id);
    }

    // Method to display rental details
    public function display() {
        echo "<p>Rental ID: {$this->id}</p>";
        echo "<p>Motorcycle ID: {$this->motorcycle_id}</p>";
        echo "<p>User ID: {$this->user_id}</p>";
        echo "<p>Start Date: {$this->start_date}</p>";
        echo "<p>End Date: {$this->end_date}</p>";
    }
}
?>
