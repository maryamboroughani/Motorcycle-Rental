<?php
require_once('CRUD.php');

class User {
    // Properties
    public $id;
    public $username;
    public $password;
    public $created;

    private $crud;

    // Constructor
    public function __construct() {
        $this->crud = new CRUD();
    }

    // Create a new user
    public function create() {
        $data = [
            'username' => $this->username,
            'password' => password_hash($this->password, PASSWORD_DEFAULT),
        ];
        return $this->crud->create('users', $data);
    }

    // Read users
    public function read($id = null) {
        return $this->crud->read('users', $id);
    }

    // Update a user
    public function update() {
        $data = [
            'username' => $this->username,
            'password' => password_hash($this->password, PASSWORD_DEFAULT),
        ];
        return $this->crud->update('users', $this->id, $data);
    }

    // Delete a user
    public function delete() {
        return $this->crud->delete('users', $this->id);
    }

    // Method to display user details
    public function display() {
        echo "<p>User ID: {$this->id}</p>";
        echo "<p>Username: {$this->username}</p>";
        echo "<p>Created: {$this->created}</p>";
    }
}
?>
