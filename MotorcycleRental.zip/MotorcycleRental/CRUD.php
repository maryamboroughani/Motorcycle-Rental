<?php
require_once 'connection.php';

class CRUD {
    private $pdo;

    public function __construct() {
        $this->pdo = Connection::getInstance();
    }

    public function selectMotorcycles() {
        $stmt = $this->pdo->query("SELECT * FROM motorcycles");
        return $stmt->fetchAll();
    }

    public function selectMotorcycleById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM motorcycles WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function insertMotorcycle($data) {
        $sql = "INSERT INTO motorcycles (brand, model, year, price, available) VALUES (:brand, :model, :year, :price, :available)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($data);
        return $this->pdo->lastInsertId();
    }

    public function updateMotorcycle($id, $data) {
        $data['id'] = $id;
        $sql = "UPDATE motorcycles SET brand = :brand, model = :model, year = :year, price = :price, available = :available WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($data);
    }

    public function deleteMotorcycle($id) {
        $stmt = $this->pdo->prepare("DELETE FROM motorcycles WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
}
?>
