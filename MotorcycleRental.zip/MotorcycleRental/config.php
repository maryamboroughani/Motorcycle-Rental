<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'motorcycle_shop');
define('DB_USER', 'root');
define('DB_PASS', 'wbKYwEC8JdG');

?>
