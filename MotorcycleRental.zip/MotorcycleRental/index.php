<?php
require_once 'CRUD.php';

// Initialize CRUD object
$crud = new CRUD();

// Example usage: Select all motorcycles
$motorcycles = $crud->selectMotorcycles();

// Example usage: Insert a new motorcycle
$newMotorcycleData = array(
    'brand' => 'Honda',
    'model' => 'CBR600RR',
    'year' => 2023,
    'price' => 12000.00,
    'available' => 1
);
$newMotorcycleId = $crud->insertMotorcycle($newMotorcycleData);

// Example usage: Update a motorcycle
$updateMotorcycleId = 1; 
$updateMotorcycleData = array(
    'brand' => 'Yamaha',
    'model' => 'YZF-R6',
    'year' => 2022,
    'price' => 11000.00,
    'available' => 1
);
$crud->updateMotorcycle($updateMotorcycleId, $updateMotorcycleData);

// Example usage: Delete a motorcycle
$deleteMotorcycleId = 2; 
$crud->deleteMotorcycle($deleteMotorcycleId);

// Display motorcycles
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Motorcycle Shop</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Motorcycle Shop</h1>

        <!-- Add New Motorcycle Form -->
        <form action="add-motorcycle.php" method="post">
            <h2>Add New Motorcycle</h2>
            <label for="brand">Brand:</label>
            <input type="text" id="brand" name="brand" required>
            <label for="model">Model:</label>
            <input type="text" id="model" name="model" required>
            <label for="year">Year:</label>
            <input type="number" id="year" name="year" required>
            <label for="price">Price:</label>
            <input type="text" id="price" name="price" required>
            <label for="available">Available:</label>
            <select id="available" name="available" required>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
            <input type="submit" value="Add Motorcycle">
        </form>

        <!-- Filter Motorcycles Form -->
        <form action="filter-motorcycles.php" method="get">
            <h2>Filter Motorcycles</h2>
            <label for="filter">Filter by Brand:</label>
            <input type="text" id="filter" name="filter">
            <input type="submit" value="Filter">
        </form>

        <!-- Display Motorcycles List -->
        <h2>Motorcycles List</h2>
        <ul class="motorcycles-list">
            <?php
            foreach ($motorcycles as $motorcycle) {
                echo '<li>';
                echo 'ID: ' . $motorcycle['id'] . ', ';
                echo 'Brand: ' . $motorcycle['brand'] . ', ';
                echo 'Model: ' . $motorcycle['model'] . ', ';
                echo 'Year: ' . $motorcycle['year'] . ', ';
                echo 'Price: ' . $motorcycle['price'] . ', ';
                echo 'Available: ' . ($motorcycle['available'] ? 'Yes' : 'No');
                echo '</li>';
            }
            ?>
        </ul>
    </div>
</body>
</html>
